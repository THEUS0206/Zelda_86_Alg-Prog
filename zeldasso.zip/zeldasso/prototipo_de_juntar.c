#include "raylib.h"

#define LARGURA_TELA 1200   // Largura da janela do jogo
#define ALTURA_TELA 860     // Altura da janela do jogo
#define ALT_STATUS    60    // Altura da barra de status superior
#define CELULA        50    // Tamanho de cada c�lula do mapa
#define COLUNAS       24    // N�mero de colunas do mapa em c�lulas
#define LINHAS        16    // N�mero de linhas do mapa em c�lulas

// Fun��o que agrupa toda a l�gica do jogo principal
void RunGame(void) {
    // --- Carregamento de texturas ---
    Texture2D texChao   = LoadTexture("chao_1200x800.png");
    Texture2D texParede = LoadTexture("parede.png");
    Texture2D texVida   = LoadTexture("vida.png");
    Texture2D texNorte  = LoadTexture("jogador-norte.png");
    Texture2D texSul    = LoadTexture("jogador-sul.png");
    Texture2D texLeste  = LoadTexture("jogador-leste.png");
    Texture2D texOeste  = LoadTexture("jogador-oeste.png");

    // Posi��o inicial do jogador (c�lulas)
    int px = COLUNAS / 2;
    int py = LINHAS / 2;
    Texture2D *skin = &texSul; // Textura inicial do jogador virado para o sul

    // --- Constru��o do mapa ---
    float escalaParede = (float)CELULA / texParede.width;
    int matriz_mapa[LINHAS][COLUNAS] = {0};
    // Preenche bordas com paredes (valor 1)
    for (int y = 0; y < LINHAS; y++) {
        for (int x = 0; x < COLUNAS; x++) {
            if (y == 0 || y == LINHAS - 1 || x == 0 || x == COLUNAS - 1) matriz_mapa[y][x] = 1;
        }
    }
    // Garante que a c�lula inicial do jogador esteja livre
    matriz_mapa[py][px] = 0;

    // Loop principal do jogo at� o usu�rio fechar ou voltar ao menu
    while (!WindowShouldClose()) {
        // --- Entrada de teclado para movimento ---
        int nx = px, ny = py;
        if (IsKeyPressed(KEY_UP))    { ny--; skin = &texNorte; }
        if (IsKeyPressed(KEY_DOWN))  { ny++; skin = &texSul;   }
        if (IsKeyPressed(KEY_LEFT))  { nx--; skin = &texOeste; }
        if (IsKeyPressed(KEY_RIGHT)) { nx++; skin = &texLeste; }
        // Verifica se nova posi��o � v�lida (dentro do mapa e sem parede)
        if (nx >= 0 && nx < COLUNAS && ny >= 0 && ny < LINHAS && matriz_mapa[ny][nx] == 0) {
            px = nx; py = ny;
        }

        // --- Renderiza��o ---
        BeginDrawing();
        ClearBackground(RAYWHITE);

        // 1) Barra de status superior
        DrawRectangle(0, 0, LARGURA_TELA, ALT_STATUS, BLACK);
        DrawText("VIDAS:", 10, 10, 20, WHITE);

        // 2) Desenha cora��es (vidas), n�vel e escore (valores fixos por enquanto)
        int vidas = 3;
        float escalaVida = 20.0f / texVida.height;
        int larguraVidas = MeasureText("VIDAS:", 20);
        int coracaoX = 10 + larguraVidas + 10;
        for (int i = 0; i < vidas; i++) {
            DrawTextureEx(texVida, (Vector2){coracaoX + i * (texVida.width * escalaVida + 5), 10}, 0.0f, escalaVida, WHITE);
        }
        DrawText(TextFormat("NIVEL: %d", 1), coracaoX + vidas * (texVida.width * escalaVida + 5) + 20, 10, 20, WHITE);
        DrawText(TextFormat("ESCORE: %d", 0), coracaoX + vidas * (texVida.width * escalaVida + 5) + 140, 10, 20, WHITE);

        // 3) Desenha ch�o e paredes do mapa
        DrawTexture(texChao, 0, ALT_STATUS, WHITE);
        for (int y = 0; y < LINHAS; y++) {
            for (int x = 0; x < COLUNAS; x++) {
                if (matriz_mapa[y][x] == 1) {
                    DrawTextureEx(texParede, (Vector2){x * CELULA, ALT_STATUS + y * CELULA}, 0.0f, escalaParede, WHITE);
                }
            }
        }

        // 4) Desenha jogador na posi��o atual
        DrawTexturePro(*skin,
                       (Rectangle){0, 0, (float)skin->width, (float)skin->height},
                       (Rectangle){(float)(px * CELULA), (float)(ALT_STATUS + py * CELULA), (float)CELULA, (float)CELULA},
                       (Vector2){0, 0}, 0.0f, WHITE);

        // 5) Instru��o para retornar ao menu
        DrawText("Pressione 'M' para voltar ao menu", 10, ALTURA_TELA - 30, 20, DARKGRAY);
        EndDrawing();

        // Se o jogador apertar 'M', volta para o menu chamador
        if (IsKeyPressed(KEY_M)) break;
    }

    // --- Limpeza de recursos ao sair do jogo ---
    UnloadTexture(texChao);
    UnloadTexture(texParede);
    UnloadTexture(texVida);
    UnloadTexture(texNorte);
    UnloadTexture(texSul);
    UnloadTexture(texLeste);
    UnloadTexture(texOeste);
}

int main(void) {
    // Inicializa janela e configura FPS
    InitWindow(LARGURA_TELA, ALTURA_TELA, "Zelda INF");
    SetTargetFPS(60);

    int opcaoSelecionada = 0; // �ndice da op��o do menu (0: Novo jogo, 1: Placar, 2: Sair)

    // Loop principal do menu
    while (!WindowShouldClose()) {
        Vector2 posicaoDoMouse = GetMousePosition();

        // Navega��o por teclado entre op��es
        if (IsKeyPressed(KEY_DOWN)) opcaoSelecionada = (opcaoSelecionada + 1) % 3;
        if (IsKeyPressed(KEY_UP))   opcaoSelecionada = (opcaoSelecionada - 1 + 3) % 3;

        // --- Sele��o via teclado ENTER ---
        if (IsKeyPressed(KEY_ENTER)) {
            if (opcaoSelecionada == 0) {
                RunGame(); // Inicia novo jogo
            } else if (opcaoSelecionada == 1) {
                // TO-DO: l�gica de placar
            } else if (opcaoSelecionada == 2) {
                break; // Sai do programa
            }
        }

        // --- Sele��o via clique do mouse ---
        if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
            Rectangle botaoNovo   = {100, 400, 200, 50};
            Rectangle botaoPlacar = {100, 500, 200, 50};
            Rectangle botaoSair   = {100, 600, 200, 50};

            if (CheckCollisionPointRec(posicaoDoMouse, botaoNovo)) {
                RunGame();
            } else if (CheckCollisionPointRec(posicaoDoMouse, botaoPlacar)) {
                // TO-DO: l�gica de placar
            } else if (CheckCollisionPointRec(posicaoDoMouse, botaoSair)) {
                break;
            }
        }

        // --- Desenha o menu na tela ---
        BeginDrawing();
        ClearBackground(BLACK);

        // T�tulo centralizado
        DrawText("ZELDASSO", LARGURA_TELA/2 - MeasureText("ZELDASSO", 40)/2, 100, 60, GREEN);

        // Defini��o e desenho dos bot�es
        Rectangle botoes[3] = {{100,400,200,50},{100,500,200,50},{100,600,200,50}};
        const char *labels[3] = {"Novo jogo","Placar","Sair"};
        for (int i = 0; i < 3; i++) {
            Color c = CheckCollisionPointRec(posicaoDoMouse, botoes[i]) ? DARKGREEN : GRAY;
            DrawRectangleRec(botoes[i], c);
            DrawText(labels[i], botoes[i].x+10, botoes[i].y+10, 20, DARKGRAY);
            if (opcaoSelecionada == i) {
                DrawRectangleLines(botoes[i].x-5, botoes[i].y-5, botoes[i].width+10, botoes[i].height+10, RED);
            }
        }

        EndDrawing();
    }

    // Fecha janela e encerra o programa
    CloseWindow();
    return 0;
}
